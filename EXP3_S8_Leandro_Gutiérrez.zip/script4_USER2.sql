-- VI LA TABLA DE DESCUENTOS ADULTOS MAYORES Y DECID� APLICAR EL DESCUENTO SEG�N LA TABLA

CREATE OR REPLACE VIEW V_RECALCULO_PAGOS AS
SELECT 
    pa.pac_run,
    pa.dv_run,
    ss.descripcion AS sist_salud,    
    pa.apaterno || ' ' || pa.pnombre AS nombre_pciente,
    bc.costo,
    CASE 
        WHEN bc.hr_consulta > '17:15' AND (bc.costo BETWEEN 15000 AND 25000)
            THEN ROUND(1.15 * bc.costo * (1 - TO_NUMBER(da.porcentaje_descto || ',0') / 100))
        WHEN bc.hr_consulta > '17:15' AND bc.costo > 25000
            THEN ROUND(1.2 * bc.costo * (1 - TO_NUMBER(da.porcentaje_descto || ',0') / 100))
        ELSE
            ROUND(bc.costo * (1 - TO_NUMBER(da.porcentaje_descto || ',0') / 100))
    END AS monto_a_cancelar,
    TRUNC(MONTHS_BETWEEN(SYSDATE, pa.fecha_nacimiento) / 12) AS edad    
FROM 
    PACIENTE pa
INNER JOIN 
    SALUD ss ON pa.sal_id = ss.sal_id
INNER JOIN 
    BONO_CONSULTA bc ON pa.pac_run = bc.pac_run
INNER JOIN 
    PAGOS pp ON bc.id_bono = pp.id_bono
LEFT JOIN 
    PCT_DESCTO_ADULTO_MAYOR da ON TRUNC(MONTHS_BETWEEN(SYSDATE, pa.fecha_nacimiento) / 12) BETWEEN da.anno_ini AND da.anno_ter
    ORDER BY pa.pac_run;
    
SELECT * FROM   V_RECALCULO_PAGOS;
    

CREATE OR REPLACE VIEW VISTA_AUM_MEDICO_X_CARGO as
SELECT TO_CHAR(SUBSTR(LPAD(TO_CHAR(med.rut_med), 8, '0'), 1, 2)) || '.' ||
       TO_CHAR(SUBSTR(LPAD(TO_CHAR(med.rut_med), 8, '0'), 3, 3)) || '.' ||
       TO_CHAR(SUBSTR(LPAD(TO_CHAR(med.rut_med), 8, '0'), 6, 3)) || '-' ||
       med.dv_run AS rut_medico,
       car.nombre AS cargo,
       med.sueldo_base,
       LPAD('$' || TO_CHAR(ROUND(med.sueldo_base * 1.15), 'FM999G999G999'), 11, ' ') AS sueldo_aumentado
FROM med
INNER JOIN car ON med.car_id = car.car_id
WHERE car.nombre LIKE '%atenc%n%'
ORDER BY med.sueldo_base;

SELECT * FROM VISTA_AUM_MEDICO_X_CARGO;



CREATE OR REPLACE VIEW VISTA_AUM_MEDICO_X_CARGO_2 as
SELECT TO_CHAR(SUBSTR(LPAD(TO_CHAR(med.rut_med), 8, '0'), 1, 2)) || '.' ||
       TO_CHAR(SUBSTR(LPAD(TO_CHAR(med.rut_med), 8, '0'), 3, 3)) || '.' ||
       TO_CHAR(SUBSTR(LPAD(TO_CHAR(med.rut_med), 8, '0'), 6, 3)) || '-' ||
       med.dv_run AS rut_medico,
       car.nombre AS cargo,
       med.sueldo_base,
       LPAD('$' || TO_CHAR(ROUND(med.sueldo_base * 1.15), 'FM999G999G999'), 11, ' ') AS sueldo_aumentado
FROM med
INNER JOIN car ON med.car_id = car.car_id
WHERE car.car_id = 400 AND med.sueldo_base < 1500000
ORDER BY med.sueldo_base;

SELECT * FROM  VISTA_AUM_MEDICO_X_CARGO_2;

-- Creaci?n de ?ndice seg?n plan de ejecuci?n en la vista VISTA_AUM_MEDICO_X_CARGO
CREATE INDEX IdCargo ON MED(car_id);